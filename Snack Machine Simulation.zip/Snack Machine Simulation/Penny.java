
/**
 * The class of Penny, requires no functionality it represents the penny object used to buy crisps from Snack Machine.
 *
 * @author (Adenuga Banjoko) 
 * @version 1 (15/11/2016)
 */

public class Penny
{
    /**
     * Empty constructor represnting penny object.
     */
    public Penny()
    {
    }
}
